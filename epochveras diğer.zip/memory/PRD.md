# Epochveras — PRD

## Original problem statement
Web-based PWA futures terminal, black TradingView-like theme, Binance USDT-M perpetual. Live chart, precise alarms, drawing tools, right-panel data modules (Watchlist, Alarms, Futures Data), Göstergeler with two native indicators (Epoch Script, CakmaUstad RSI — user supplied the Pine code). Account sync across devices, email+password+verification, 24/7 server-side alarms. (Full original text is in the first chat message.)

## User choices
- Timeframes: 1m,3m,5m,15m,30m,1h,4h,1d,1w (labels 1dk…30dk, 1sa, 4sa, 1G, 1H)
- Email: Emergent managed (verification is handled by Emergent-managed Clerk auth)
- Scope: working first version of all phases

## Architecture
- Backend FastAPI: `server.py` (settings/drawings/alarms/push/WS sync), `market.py` (Binance REST proxy via https://www.binance.com — fapi.binance.com is geo-blocked from server), `alarms.py` (AlarmEngine: Binance aggTrade WS `wss://fstream.binance.com/market/ws`, dynamic SUBSCRIBE, one-shot cross detection, REST catch-up on reconnect, web push via pywebpush/VAPID), `clerk_auth.py`.
- Mongo collections: settings (layout, favorites, drawing_styles, indicators, last_symbol, last_tf, sound), drawings (time+price points), alarms, push_subs.
- Frontend React (JS, CRA) + lightweight-charts 4.2: canvas overlay for drawings & Epoch visuals, RSI sub-chart synced to main, browser-direct Binance WS (`REACT_APP_BINANCE_WS`) with REST polling fallback; service worker (push + offline shell), manifest.

## Implemented (2026-06)
- Auth (Clerk email+password+email code), sign-in page with live tickers
- Chart: live candles, 9 TFs, countdown, full tr-TR prices by tick size
- Drawings: trendline, horizontal ray, long/short template (hit/progress coloring), soft magnet, ruler; color/width with remembered style; time-based storage; cross-device realtime sync over /api/ws
- Right panel: modules toggle/collapse/close, panel width drag + widen/narrow, module height resize; mobile bottom sheet
- Watchlist: Tümü/Favoriler/custom groups/Emtia (TradFi commodity perps), search, sort, star, group menu, funding with (Xs) label, virtualized rows
- Alarms: price-scale “+”, small tag only, delete, server 24/7 engine, sound, toast, web push (opt-in)
- Futures Data: funding, next funding countdown, OI (+value), L/S account ratio, top-trader position ratio bars, period switch
- Epoch Script native: EMA 100/200/300, EMA 38/62 colored + cloud, pivot-break bar colors, yellow/aqua candles, triangles, entry arrows, dual auto trendlines, SFP (lines/wick/labels/confirm), MTF SFP & pivot tables, RSI divergence (zigzag) — all inputs/colors/toggles editable
- CakmaUstad RSI native: RSI 22 / EMA 66, fill, bands, pivot trendlines (+broken, extend, style/width/colors), pivot lines, ATR table
- Tests: iteration_1 & 2 all passing (backend 30/30)

## Backlog
- P1: SFP volume validation (LTF data), history lazy-load on scroll-left, alert email option
- P1: Persist RSI pane height, drawing undo, more drawing types
- P2: TypeScript migration (user asked React+TS; v1 written in JS), load tests, multiple-pod alarm engine leader election

## Iteration 2026-06 (feedback rounds)
- Monochrome UI (black/white/gray), TradingView font stack, logo everywhere (header, auth, favicon, PWA icons incl. maskable)
- TradingView-like header (logo, symbol search, TFs, Göstergeler, Alarm popover, Canlı·UTC), right icon rail with alarm badge
- Watchlist price flash, chart legend (OHLC + Epoch), visible grid, time axis at bottom (RSI pane), small MTF tables
- Epoch: filled D/H pin labels, EMA cloud on back canvas behind candles (opacity 0.5)
- CakmaUstad: per-band toggles 70/58/50/42/30 + 70-30 background fill
- Futures: L/S account, top-trader account & position ratios; period buttons removed
- Full-precision price scale per tick size (custom series formatter)
